"""Visitor-initiated delivery to ONE fixed, owner-configured messaging destination."""
import hashlib,hmac,json,os,re,secrets,time,urllib.request
from storage import atomic,catalog
CHANNELS=('whatsapp','viber','telegram','instagram','facebook','email')

def available():
 return {'telegram':bool(re.fullmatch(r'\d+:[A-Za-z0-9_-]+',os.getenv('TELEGRAM_BOT_TOKEN','')) and re.fullmatch(r'-?\d+',os.getenv('TELEGRAM_CHAT_ID',''))),
 'whatsapp':bool(os.getenv('WHATSAPP_ACCESS_TOKEN') and os.getenv('WHATSAPP_PHONE_ID','').isdigit() and re.fullmatch(r'[1-9]\d{6,14}',os.getenv('WHATSAPP_OWNER_NUMBER','')) and re.fullmatch(r'[a-z0-9_]+',os.getenv('WHATSAPP_TEMPLATE','')) and os.getenv('WHATSAPP_TEMPLATE_LANGUAGE')),
 'viber':bool(os.getenv('VIBER_BOT_TOKEN') and os.getenv('VIBER_OWNER_ID'))}

def mac(v):
 secret=os.getenv('SESSION_SECRET','')
 if len(secret)<32:raise ValueError('Messaging is not configured')
 return hmac.new(secret.encode(),v.encode(),hashlib.sha256).hexdigest()
def issue_token():
 value=str(int(time.time()))+'.'+secrets.token_hex(24);return value+'.'+mac(value)
def verify_token(token):
 try:
  value,sig=token.rsplit('.',1);stamp=int(value.split('.')[0]);age=time.time()-stamp
  if not 2<=age<=900 or not hmac.compare_digest(mac(value),sig):raise ValueError()
 except (ValueError,AttributeError,TypeError):raise ValueError('Refresh the form and try again after a few seconds')

def short(payload,key,maximum,required=False):
 v=payload.get(key,'')
 if not isinstance(v,str) or len(v)>maximum or (required and not v.strip()) or any(ord(c)<32 and c not in '\n\t' for c in v):raise ValueError('Invalid '+key)
 return v.strip()
def build_message(state,payload):
 if payload.get('language','en') not in ('en','uk','ru','pl'):raise ValueError('Invalid language')
 name=short(payload,'name',80,True);contact=short(payload,'contact',160,True);notes=short(payload,'notes',900);lang=payload.get('language','en')
 def tr(v):return v.get(lang) or v.get('en') or next(iter(v.values()),'')
 lines=['Website inquiry · '+state['settings']['brand'],'Customer: '+name,'Reply contact: '+contact]
 product_id=payload.get('productId')
 if product_id:
  p=next((p for p in state['products'] if p['id']==product_id and p.get('published')),None)
  if not p:raise ValueError('Product is unavailable')
  q=payload.get('quantity');size=payload.get('size')
  if type(q) is not int or not 1<=q<=20 or (p['kind']=='limited' and q>p['stock']):raise ValueError('Quantity is unavailable')
  if size not in p['sizes']:raise ValueError('Choose a valid size')
  lines.extend(['Product: '+tr(p['name'])[:160],'ID: '+p['id'],'Size: '+size,'Quantity: '+str(q),'Price: '+('Ask for pricing' if p['price'] is None else str(p['price'])+' '+state['settings']['currency']+' each; subtotal '+str(round(p['price']*q,2)))])
 else:lines.append('General / custom request')
 lines.extend(['Customer wishes: '+notes,'Inquiry only. Confirm final price, availability, delivery and payment with the customer.'])
 return '\n'.join(lines)

def provider_send(channel,message):
 if channel=='telegram':
  url='https://api.telegram.org/bot'+os.environ['TELEGRAM_BOT_TOKEN']+'/sendMessage';headers={};payload={'chat_id':os.environ['TELEGRAM_CHAT_ID'],'text':message,'link_preview_options':{'is_disabled':True}}
 elif channel=='viber':
  url='https://chatapi.viber.com/pa/send_message';headers={'X-Viber-Auth-Token':os.environ['VIBER_BOT_TOKEN']};payload={'receiver':os.environ['VIBER_OWNER_ID'],'min_api_version':1,'sender':{'name':'Atelier orders'},'type':'text','text':message}
 elif channel=='whatsapp':
  version=os.getenv('META_GRAPH_VERSION','v25.0')
  if not re.fullmatch(r'v\d+\.0',version):raise ValueError('Invalid API version')
  url='https://graph.facebook.com/'+version+'/'+os.environ['WHATSAPP_PHONE_ID']+'/messages';headers={'Authorization':'Bearer '+os.environ['WHATSAPP_ACCESS_TOKEN']}
  # Approved template BODY must have exactly one text parameter {{1}}.
  compact=' · '.join(message.splitlines())
  if len(compact)>1000:raise ValueError('Request is too long for the approved WhatsApp template. Shorten the notes.')
  payload={'messaging_product':'whatsapp','to':os.environ['WHATSAPP_OWNER_NUMBER'],'type':'template','template':{'name':os.environ['WHATSAPP_TEMPLATE'],'language':{'code':os.environ['WHATSAPP_TEMPLATE_LANGUAGE']},'components':[{'type':'body','parameters':[{'type':'text','text':compact}]}]}}
 else:raise ValueError('Automatic delivery is unavailable for this channel')
 req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers={**headers,'Content-Type':'application/json'},method='POST')
 # Never log provider URLs/exceptions: Telegram embeds its credential in the URL.
 with urllib.request.urlopen(req,timeout=15) as r:result=json.loads(r.read(200000))
 ok=result.get('ok') is True if channel=='telegram' else (result.get('status')==0 if channel=='viber' else bool(result.get('messages')))
 if not ok:raise RuntimeError('Provider did not accept request')

def deliver(payload,address):
 if not isinstance(payload,dict):raise ValueError('Invalid request')
 state=catalog();settings=state['settings'];channel=settings.get('orderChannel','whatsapp')
 if not settings.get('automaticOrders') or not available().get(channel):raise ValueError('Automatic delivery is not connected. Use the chat link instead.')
 if payload.get('consent') is not True:raise ValueError('Consent is required before sending')
 if payload.get('channel')!=channel:raise ValueError('The owner changed the delivery channel. Refresh the form.')
 if payload.get('website'):raise ValueError('Invalid request')
 verify_token(payload.get('token'));message=build_message(state,payload)
 # Reserve one use before contacting the provider; no silent retries after ambiguous timeouts.
 key='limit-order-'+hashlib.sha256(payload['token'].encode()).hexdigest();claim_id=secrets.token_hex(24)
 def claim(old):
  return old or {'expires':time.time()+86400,'state':'pending','claimId':claim_id}
 committed=atomic(key,claim)
 if committed.get('claimId')!=claim_id:raise ValueError('This request was already submitted. Do not send it again.')
 for key,maximum in [('ip-'+hashlib.sha256(address.encode()).hexdigest(),5),('global',50)]:
  now=time.time()
  def rate(old):
   old=old or {'start':now,'count':0}
   if now-old['start']>900:old={'start':now,'count':0}
   return {'start':old['start'],'count':old['count']+1}
  if atomic('limit-order-rate-'+key,rate)['count']>maximum:raise ValueError('Too many requests. Please use the chat link or try later.')
 try:provider_send(channel,message)
 except ValueError:raise
 except Exception:raise RuntimeError('Delivery could not be confirmed. Do not automatically resend; contact the owner through chat.') from None
 return {'accepted':True,'channel':channel}
