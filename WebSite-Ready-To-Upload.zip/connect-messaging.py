"""One-time owner messaging setup for an already deployed Google Cloud service."""
import argparse,getpass,json,re,subprocess,urllib.request

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--service',default='vytka-atelier');p.add_argument('--region',default='us-central1');p.add_argument('--provider',choices=['telegram','whatsapp','viber'],required=True);a=p.parse_args()
 for value in [a.project,a.service,a.region]:
  if not re.fullmatch(r'[a-zA-Z0-9-]+',value):p.error('Invalid option')
 base=['gcloud','--project',a.project,'--quiet']
 def cmd(args,data=None,capture=False):
  r=subprocess.run(base+args,input=data,text=True,capture_output=capture)
  if r.returncode:raise SystemExit('Google setup failed. Review the command error and retry.')
  return r.stdout.strip() if capture else ''
 service=cmd(['run','services','describe',a.service,'--region='+a.region,'--format=value(spec.template.spec.serviceAccountName)'],capture=True)
 if not service:raise SystemExit('Runtime service account not found. Deploy the site first.')
 token=getpass.getpass('Authorized '+a.provider+' bot/business access token (hidden): ').strip()
 if not token:raise SystemExit('A token is required.')
 settings={};key={'telegram':'TELEGRAM_BOT_TOKEN','whatsapp':'WHATSAPP_ACCESS_TOKEN','viber':'VIBER_BOT_TOKEN'}[a.provider]
 if a.provider=='telegram':
  chat=input('Owner chat ID (blank to look up after sending /start to your bot): ').strip()
  if not chat:
   try:
    req=urllib.request.Request('https://api.telegram.org/bot'+token+'/getUpdates',data=b'limit=20',method='POST')
    with urllib.request.urlopen(req,timeout=15) as r:updates=json.loads(r.read(500000))
    ids=sorted({str(x['message']['chat']['id']) for x in updates.get('result',[]) if x.get('message',{}).get('chat',{}).get('type')=='private'})
   except Exception:raise SystemExit('Could not look up chats. Check the token and try again. No token was printed.') from None
   if not ids:raise SystemExit('Send /start to the bot from the owner account, then rerun.')
   print('Private chat IDs seen by your bot: '+', '.join(ids));chat=input('Enter the owner chat ID from the list: ').strip()
   if chat not in ids:raise SystemExit('Choose one of the listed IDs.')
  if not re.fullmatch(r'-?\d+',chat):raise SystemExit('Invalid chat ID')
  settings['TELEGRAM_CHAT_ID']=chat
 elif a.provider=='whatsapp':
  for env,label,pattern in [('WHATSAPP_PHONE_ID','WhatsApp Business sender phone-number ID',r'\d+'),('WHATSAPP_OWNER_NUMBER','Opted-in owner recipient phone (country code, digits only)',r'[1-9]\d{6,14}'),('WHATSAPP_TEMPLATE','Approved template name (one body parameter)',r'[a-z0-9_]+'),('WHATSAPP_TEMPLATE_LANGUAGE','Approved template language code, e.g. en_US',r'[a-zA-Z_]+')]:
   value=input(label+': ').strip()
   if not re.fullmatch(pattern,value):raise SystemExit('Invalid '+label)
   settings[env]=value
 else:settings['VIBER_OWNER_ID']=input('Subscribed owner Viber user ID: ').strip()
 if any(not v for v in settings.values()):raise SystemExit('All fields are required.')
 secret=a.service+'-'+a.provider+'-orders-token'
 exists=subprocess.run(base+['secrets','describe',secret],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 if not exists:cmd(['secrets','create',secret,'--replication-policy=automatic'])
 version=cmd(['secrets','versions','add',secret,'--data-file=-','--format=value(name)'],token,True).rsplit('/',1)[-1]
 cmd(['secrets','add-iam-policy-binding',secret,'--member=serviceAccount:'+service,'--role=roles/secretmanager.secretAccessor','--condition=None'])
 cmd(['run','services','update',a.service,'--region='+a.region,'--update-secrets='+key+'='+secret+':'+version,'--update-env-vars='+','.join(k+'='+v for k,v in settings.items())])
 print('Server credentials configured. In /admin → Social & journal, select '+a.provider+', enable direct delivery, save, and submit ONE test inquiry from the storefront. Configuration does not guarantee provider acceptance.')
if __name__=='__main__':main()
