"""Boutique WSGI application. Run with gunicorn on Cloud Run."""
import base64, hashlib, hmac, io, json, mimetypes, os, re, secrets, time, traceback, urllib.parse
from http.cookies import SimpleCookie
from pathlib import Path
from storage import catalog, save_catalog, get, put, atomic, throttle, DATA
ROOT=Path(__file__).parent;PUBLIC=ROOT/'public'
SECRET=os.getenv('SESSION_SECRET','')
PASSWORD=os.getenv('ADMIN_PASSWORD_HASH','')
CLOUD=os.getenv('STORE_BACKEND')=='firestore'
SECURE=os.getenv('COOKIE_SECURE','true').lower()!='false'
LANGS={'en','uk','ru','pl'}
class HttpError(Exception):
 def __init__(self,status,message):self.status=status;self.message=message

def fail(status,message):raise HttpError(status,message)
def body(env,limit=800_000):
 try:n=int(env.get('CONTENT_LENGTH') or 0)
 except ValueError:fail(400,'Invalid request length')
 if n<0 or n>limit:fail(413,'Request too large')
 try:return json.loads(env['wsgi.input'].read(n))
 except (ValueError,UnicodeError):fail(400,'Invalid JSON')

def signature(s):return hmac.new(SECRET.encode(),s.encode(),hashlib.sha256).hexdigest()
def password_ok(value):
 try:
  salt,target=PASSWORD.split(':');result=hashlib.scrypt(str(value).encode(),salt=salt.encode(),n=16384,r=8,p=1).hex();return hmac.compare_digest(target,result)
 except (ValueError,TypeError):return False

def cookie(value,maxage=28800):return f'atelier_session={value}; Path=/; HttpOnly; SameSite=Strict; Max-Age={maxage}'+('; Secure' if SECURE else '')
def session(env,csrf=False):
 jar=SimpleCookie()
 try:jar.load(env.get('HTTP_COOKIE',''));token=jar['atelier_session'].value;sid,sig=token.rsplit('.',1)
 except (KeyError,ValueError):fail(401,'Please sign in')
 if not SECRET or not hmac.compare_digest(signature(sid),sig):fail(401,'Please sign in')
 s=get('session-'+sid)
 if not s or s['expires']<time.time() or s.get('version')!=hashlib.sha256(PASSWORD.encode()).hexdigest():fail(401,'Session expired. Please sign in again')
 if csrf and not hmac.compare_digest(s['csrf'],env.get('HTTP_X_CSRF_TOKEN','')):fail(403,'Refresh the page and try again')
 return sid,s

def textmap(v,label,required=False):
 if not isinstance(v,dict) or not set(v)<=LANGS or any(not isinstance(x,str) or len(x)>12000 for x in v.values()):fail(400,'Invalid translations: '+label)
 if required and not any(x.strip() for x in v.values()):fail(400,label+' is required')

def safe_url(v,hosts=None,local=False):
 if not isinstance(v,str) or len(v)>2048:return False
 if not v:return True
 if local and re.fullmatch(r'/(assets|media)/[a-zA-Z0-9_.-]+',v):return True
 u=urllib.parse.urlparse(v)
 return u.scheme=='https' and bool(u.hostname) and not u.username and not u.password and (not hosts or u.hostname.lower() in hosts)

def validate(d):
 if not isinstance(d,dict) or set(d)!={'revision','settings','categories','products','pages','posts'}:fail(400,'Invalid catalog structure')
 if len(json.dumps(d).encode())>750000:fail(413,'Catalog text exceeds 750 KB. Export and archive unused items.')
 s=d['settings']
 if not isinstance(s,dict):fail(400,'Invalid settings')
 for k in ['tagline','heroTitle','heroText','story','shipping']:textmap(s.get(k),k)
 if not isinstance(s.get('brand'),str) or not 1<=len(s['brand'])<=80:fail(400,'Store name is required (maximum 80 characters)')
 if s.get('defaultLang') not in LANGS:fail(400,'Invalid default language')
 if not re.fullmatch('[A-Z]{3}',str(s.get('currency',''))):fail(400,'Use a three-letter currency code')
 if not re.fullmatch('#[0-9a-fA-F]{6}',str(s.get('accent',''))):fail(400,'Invalid accent color')
 for k,hosts in [('instagram',{'instagram.com','www.instagram.com'}),('facebook',{'facebook.com','www.facebook.com','m.me'})]:
  if not safe_url(s.get(k,''),hosts):fail(400,'Use the full HTTPS '+k+' profile URL')
 from orders import CHANNELS
 if s.get('orderChannel','whatsapp') not in CHANNELS:fail(400,'Invalid order channel')
 if type(s.get('automaticOrders',False)) is not bool:fail(400,'Invalid delivery mode')
 for k in ['whatsapp','viberPhone']:
  if s.get(k) and (not isinstance(s[k],str) or not re.fullmatch(r'\+[1-9]\d{6,14}',s[k])):fail(400,'Use an international phone number with + and country code')
 if s.get('telegram') and not safe_url(s['telegram'],{'t.me','telegram.me'}):fail(400,'Use a Telegram profile HTTPS link')
 if not safe_url(s.get('heroImage',''),local=True):fail(400,'Invalid hero image')
 for flag in ['heritage','demo','setupDone']:
  if flag in s and type(s[flag]) is not bool:fail(400,'Invalid setting: '+flag)
 if s.get('paymentProvider') not in ['disabled','paypal','stripe']:fail(400,'Invalid payment provider')
 if len(s.get('contactEmail',''))>254 or (s.get('contactEmail') and not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+',s['contactEmail'])):fail(400,'Invalid contact email')
 for field,maximum in [('products',500),('categories',40),('pages',30),('posts',12)]:
  if not isinstance(d[field],list) or len(d[field])>maximum:fail(400,'Too many '+field)
  ids=[]
  for x in d[field]:
   if not isinstance(x,dict) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',str(x.get('id',''))):fail(400,'Invalid item ID')
   ids.append(x['id'])
  if len(set(ids))!=len(ids):fail(400,'Duplicate IDs')
 cats={c['id'] for c in d['categories']}
 for c in d['categories']:textmap(c.get('name'),'category name',True)
 for p in d['products']:
  for field in ['name','description','leadTime','material','care']:textmap(p.get(field),field,field=='name')
  if p.get('category') not in cats:fail(400,'Choose an existing collection')
  if p.get('kind') not in ['custom','limited']:fail(400,'Invalid availability')
  if any(type(p.get(k)) is not bool for k in ['published','featured']):fail(400,'Invalid product visibility')
  price=p.get('price')
  if price is not None and (type(price) not in [int,float] or not 0<=price<=10000000):fail(400,'Price must be zero or more, or blank')
  if p.get('kind')=='limited' and (type(p.get('stock'))!=int or not 0<=p['stock']<=100000):fail(400,'Stock must be a whole number')
  if not isinstance(p.get('sizes'),list) or not 1<=len(p['sizes'])<=30 or any(not isinstance(x,str) or len(x)>80 for x in p['sizes']):fail(400,'Add at least one valid size')
  if not isinstance(p.get('images'),list) or len(p['images'])>12 or any(not safe_url(u,local=True) for u in p['images']):fail(400,'Invalid product images')
 for p in d['pages']:textmap(p.get('title'),'page title',True);textmap(p.get('body'),'page body')
 for p in d['posts']:
  textmap(p.get('caption'),'post caption')
  if not safe_url(p.get('url',''),{'instagram.com','www.instagram.com','facebook.com','www.facebook.com'}) or not p.get('url'):fail(400,'Use an Instagram or Facebook post URL')
  if not safe_url(p.get('image',''),local=True):fail(400,'Invalid post image')
 return d

def image_upload(env):
 payload=body(env,8_500_000)
 try:raw=base64.b64decode(payload['data'],validate=True)
 except (KeyError,ValueError,TypeError):fail(400,'Invalid image')
 if len(raw)>6_000_000:fail(413,'Choose an image smaller than 6 MB')
 try:
  from PIL import Image,ImageOps,UnidentifiedImageError
  Image.MAX_IMAGE_PIXELS=24000000
  with Image.open(io.BytesIO(raw)) as img:
   if img.width*img.height>24000000:fail(400,'Image dimensions are too large')
   img=ImageOps.exif_transpose(img).convert('RGB');img.thumbnail((2200,2200));out=io.BytesIO();img.save(out,format='JPEG',quality=88);raw=out.getvalue()
 except HttpError:raise
 except Exception:fail(400,'Choose a valid JPEG, PNG, or WebP photograph')
 name=secrets.token_hex(16)+'.jpg'
 if CLOUD:
  from google.cloud import storage
  storage.Client().bucket(os.environ['IMAGE_BUCKET']).blob(name).upload_from_string(raw,content_type='image/jpeg')
 else:
  (DATA/'uploads').mkdir(exist_ok=True);(DATA/'uploads'/name).write_bytes(raw)
 return {'url':'/media/'+name}

def dispatch(env):
 path=env.get('PATH_INFO','/');method=env['REQUEST_METHOD']
 if path=='/healthz':return 200,{'status':'ok'},[]
 if path=='/api/login' and method=='POST':
  if len(SECRET)<32 or not PASSWORD:fail(503,'Administrator credentials are not configured. Follow README setup.')
  p=body(env,4096);key=hashlib.sha256((env.get('REMOTE_ADDR','')+signature('throttle')).encode()).hexdigest()
  if not throttle(key):fail(429,'Too many attempts. Wait 15 minutes before trying again.')
  if not password_ok(p.get('password','')):fail(401,'Incorrect password')
  sid=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32);put('session-'+sid,{'csrf':csrf,'expires':time.time()+28800,'version':hashlib.sha256(PASSWORD.encode()).hexdigest()})
  return 200,{'csrf':csrf},[('Set-Cookie',cookie(sid+'.'+signature(sid)))]
 if path=='/api/session' and method=='GET':
  _,s=session(env);return 200,{'csrf':s['csrf']},[]
 if path=='/api/logout' and method=='POST':
  sid,_=session(env,True);put('session-'+sid,{'expires':0});return 200,{'ok':True},[('Set-Cookie',cookie('',0))]
 if path=='/api/catalog':
  if method=='GET':
   d=catalog()
   try:session(env);admin=True
   except HttpError:admin=False
   if not admin:
    d['products']=[p for p in d['products'] if p.get('published')];d['pages']=[p for p in d['pages'] if p.get('published')]
    for k in ['paymentNotes','setupDone']:d['settings'].pop(k,None)
   return 200,d,[]
  if method=='PUT':
   session(env,True);d=validate(body(env))
   try:d=save_catalog(d)
   except RuntimeError:fail(409,'Another administrator saved changes. Reload before editing again.')
   return 200,d,[]
 if path=='/api/order-status' and method=='GET':
  from orders import available,issue_token
  s=catalog()['settings'];ready=bool(s.get('automaticOrders') and available().get(s.get('orderChannel')))
  return 200,{'ready':ready,'channel':s.get('orderChannel','whatsapp'),'token':issue_token() if ready else None},[]
 if path=='/api/messaging-status' and method=='GET':
  session(env)
  from orders import available
  return 200,available(),[]
 if path=='/api/inquiries' and method=='POST':
  from orders import deliver
  try:result=deliver(body(env,12000),env.get('REMOTE_ADDR','unknown'))
  except ValueError as e:fail(400,str(e))
  except RuntimeError as e:fail(502,str(e))
  return 200,result,[]
 if path=='/api/social-feed' and method=='GET':
  from social import public_feed
  return 200,public_feed(),[]
 if path=='/api/social-status' and method=='GET':
  session(env)
  from social import status as social_status
  return 200,social_status(),[]
 if path=='/api/social-sync' and method=='POST':
  session(env,True)
  from social import sync
  return 200,sync(),[]
 if path=='/tasks/social-sync' and method=='POST':
  from social import verify_scheduler,sync
  if not verify_scheduler(env):fail(401,'Unauthorized')
  return 200,sync(),[]
 if path=='/api/upload' and method=='POST':session(env,True);return 201,image_upload(env),[]
 if path.startswith('/api/'):fail(404,'Not found')
 if method not in ['GET','HEAD']:fail(405,'Method not allowed')
 if path.startswith('/media/'):
  name=path.rsplit('/',1)[1]
  if not re.fullmatch(r'[0-9a-f]{32}\.jpg',name):fail(404,'Not found')
  if CLOUD:
   from google.cloud import storage
   blob=storage.Client().bucket(os.environ['IMAGE_BUCKET']).blob(name)
   if not blob.exists():fail(404,'Not found')
   return 200,blob.download_as_bytes(),[('Content-Type','image/jpeg'),('Cache-Control','public, max-age=86400')]
  target=DATA/'uploads'/name
 else:
  file='admin.html' if path.rstrip('/')=='/admin' else ('index.html' if path=='/' else path.lstrip('/'))
  target=(PUBLIC/file).resolve()
  if PUBLIC.resolve() not in target.parents:fail(404,'Not found')
 if not target.is_file():fail(404,'Not found')
 return 200,target.read_bytes(),[('Content-Type',mimetypes.guess_type(target.name)[0] or 'application/octet-stream'),('Cache-Control','no-cache' if target.suffix in ['.html','.js','.css'] else 'public, max-age=86400')]

def application(env,start_response):
 try:status,data,headers=dispatch(env)
 except HttpError as e:status,data,headers=e.status,{'error':e.message},[]
 except Exception:
  traceback.print_exc();status,data,headers=500,{'error':'The service could not complete the request. Please try again.'},[]
 if isinstance(data,(dict,list)):
  data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode();headers.append(('Content-Type','application/json; charset=utf-8'))
 headers.extend([('X-Content-Type-Options','nosniff'),('Referrer-Policy','strict-origin-when-cross-origin'),('X-Frame-Options','DENY'),('Permissions-Policy','camera=(), microphone=(), geolocation=()'),('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; font-src 'self'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")])
 if env.get('PATH_INFO','').startswith('/api/'):headers.append(('Cache-Control','no-store'))
 if SECURE:headers.append(('Strict-Transport-Security','max-age=31536000'))
 headers.append(('Content-Length',str(len(data))))
 start_response(str(status)+' '+{200:'OK',201:'Created',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',409:'Conflict',413:'Payload Too Large',429:'Too Many Requests',500:'Internal Server Error',502:'Bad Gateway',503:'Service Unavailable'}.get(status,'Error'),headers)
 return [b'' if env.get('REQUEST_METHOD')=='HEAD' else data]
if __name__=='__main__':
 from wsgiref.simple_server import make_server
 print('Boutique: http://localhost:'+os.getenv('PORT','8080')+' • Admin: /admin')
 make_server('0.0.0.0',int(os.getenv('PORT','8080')),application).serve_forever()
