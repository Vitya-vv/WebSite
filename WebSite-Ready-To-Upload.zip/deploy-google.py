"""Run in authenticated Google Cloud Shell. Creates paid resources in YOUR project."""
import argparse,json,re,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--region',default='us-central1');p.add_argument('--service',default='vytka-atelier');a=p.parse_args()
 if not re.fullmatch(r'[a-z][a-z0-9-]{4,28}[a-z0-9]',a.project):p.error('Invalid Google project ID')
 if not re.fullmatch(r'[a-z]+-[a-z]+[0-9]',a.region):p.error('Invalid region')
 if not re.fullmatch(r'[a-z][a-z0-9-]{1,25}',a.service):p.error('Invalid service name')
 if not shutil.which('gcloud'):raise SystemExit('Install Google Cloud CLI or use Google Cloud Shell.')
 config=ROOT/'local-config.json'
 if not config.exists():raise SystemExit('First run python setup.py to choose your administrator password.')
 credentials=json.loads(config.read_text())
 base=['gcloud','--project',a.project,'--quiet']
 def cmd(args,data=None,capture=False):
  r=subprocess.run(base+args,input=data,text=True,cwd=ROOT,capture_output=capture)
  if r.returncode:raise SystemExit('Google operation failed. Resolve the error above and rerun. Existing resources are retained.')
  return r.stdout.strip() if capture else ''
 def exists(args):
  r=subprocess.run(base+args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=ROOT)
  return r.returncode==0
 # Explicit target project on every call; do not change the user's default CLI project.
 cmd(['services','enable','run.googleapis.com','cloudbuild.googleapis.com','artifactregistry.googleapis.com','firestore.googleapis.com','storage.googleapis.com','secretmanager.googleapis.com','iam.googleapis.com'])
 number=cmd(['projects','describe',a.project,'--format=value(projectNumber)'],capture=True)
 account=a.service+'@'+a.project+'.iam.gserviceaccount.com';member='serviceAccount:'+account
 if not exists(['iam','service-accounts','describe',account]):cmd(['iam','service-accounts','create',a.service,'--display-name=Atelier runtime'])
 cmd(['projects','add-iam-policy-binding',a.project,'--member='+member,'--role=roles/datastore.user','--condition=None'])
 # Source builds use Google's documented default build identity, separate from the runtime.
 cmd(['projects','add-iam-policy-binding',a.project,'--member=serviceAccount:'+number+'-compute@developer.gserviceaccount.com','--role=roles/run.builder','--condition=None'])
 if not exists(['firestore','databases','describe','--database=(default)']):cmd(['firestore','databases','create','--database=(default)','--location='+a.region,'--type=firestore-native'])
 else:
  db=json.loads(cmd(['firestore','databases','describe','--database=(default)','--format=json'],capture=True))
  if db.get('type')!='FIRESTORE_NATIVE':raise SystemExit('The default database must use Firestore Native mode. Use a dedicated project.')
 bucket=a.project+'-'+a.service+'-images'
 if not exists(['storage','buckets','describe','gs://'+bucket]):cmd(['storage','buckets','create','gs://'+bucket,'--location='+a.region,'--uniform-bucket-level-access','--public-access-prevention'])
 details=json.loads(cmd(['storage','buckets','describe','gs://'+bucket,'--format=json'],capture=True))
 owner=str(details.get('projectNumber') or details.get('project_number') or '')
 if owner and owner!=number:raise SystemExit('Bucket belongs to a different project. Use another service name.')
 cmd(['storage','buckets','add-iam-policy-binding','gs://'+bucket,'--member='+member,'--role=roles/storage.objectUser'])
 cmd(['storage','buckets','update','gs://'+bucket,'--versioning'])
 secret_flags=[]
 for envkey,suffix in [('SESSION_SECRET','session'),('ADMIN_PASSWORD_HASH','admin-password')]:
  secret=a.service+'-'+suffix
  if not exists(['secrets','describe',secret]):cmd(['secrets','create',secret,'--replication-policy=automatic'])
  # Secret contents pass via stdin; never placed in command-line arguments.
  version=cmd(['secrets','versions','add',secret,'--data-file=-','--format=value(name)'],data=credentials[envkey],capture=True).rsplit('/',1)[-1]
  cmd(['secrets','add-iam-policy-binding',secret,'--member='+member,'--role=roles/secretmanager.secretAccessor','--condition=None'])
  secret_flags.append(envkey+'='+secret+':'+version)
 cmd(['run','deploy',a.service,'--source=.','--region='+a.region,'--service-account='+account,'--allow-unauthenticated','--port=8080','--memory=512Mi','--cpu=1','--min-instances=0','--max-instances=3','--concurrency=16','--timeout=60','--update-env-vars=STORE_BACKEND=firestore,IMAGE_BUCKET='+bucket+',COOKIE_SECURE=true','--update-secrets='+','.join(secret_flags)])
 url=cmd(['run','services','describe',a.service,'--region='+a.region,'--format=value(status.url)'],capture=True)
 print('\nStorefront: '+url+'\nAdministrator: '+url+'/admin\nNext: enable Firestore scheduled backups/PITR and review a Google billing budget. See README.md.')
if __name__=='__main__':main()
