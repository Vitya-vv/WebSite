"""Create local admin credentials. Never prints or stores the password itself."""
import getpass,hashlib,json,os,secrets
from pathlib import Path

def main():
 p=Path(__file__).parent/'local-config.json'
 if p.exists() and input('Replace administrator credentials and invalidate all sessions? [y/N] ').lower()!='y':return
 password=getpass.getpass('Choose administrator password (at least 14 characters): ')
 if len(password)<14:raise SystemExit('Please use at least 14 characters.')
 if password!=getpass.getpass('Repeat password: '):raise SystemExit('Passwords do not match.')
 salt=secrets.token_hex(16);value=salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
 with os.fdopen(fd,'w') as f:json.dump({'ADMIN_PASSWORD_HASH':value,'SESSION_SECRET':secrets.token_urlsafe(48)},f)
 try:os.chmod(p,0o600)
 except OSError:pass
 print('Administrator configured. Run: python run.py. Sign in at http://localhost:8080/admin')
if __name__=='__main__':main()
