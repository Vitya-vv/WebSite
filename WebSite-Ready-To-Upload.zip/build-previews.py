"""Create self-contained, offline storefront and nonprivileged admin previews."""
import base64,json,mimetypes
from pathlib import Path
from seed import initial_catalog
ROOT=Path(__file__).parent

def data_url(path):
 mime=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
 return 'data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()
assets={'/assets/'+p.name:data_url(p) for p in (ROOT/'public/assets').iterdir() if p.is_file()}
state=json.dumps(initial_catalog(),ensure_ascii=False)
for src,url in assets.items():state=state.replace(src,url)
# JSON in an inline script must not contain a closing script delimiter.
state=state.replace('</','<\\/')
mock=f'const previewSeed={state};window.fetch=async function(url){{return {{ok:true,status:200,json:async()=>String(url).includes("social-feed")?[]:structuredClone(previewSeed)}}}};'
for mode in ['store','admin']:
 source=ROOT/'public'/('index.html' if mode=='store' else 'admin.html')
 html=source.read_text()
 for css in ['style.css','admin.css']:
  html=html.replace('<link rel="stylesheet" href="/'+css+'">','<style>'+(ROOT/'public'/css).read_text()+'</style>')
 scripts=['i18n.js','store.js'] if mode=='store' else ['i18n.js','admin-i18n.js','admin.js']
 for js in scripts:html=html.replace('<script src="/'+js+'" defer></script>','')
 html=html.replace('href="/admin?demo=1"','href="Admin-Preview.html"').replace('href="/admin"','href="Admin-Preview.html"').replace('href="/"','href="Storefront-Preview.html"')
 for src,url in assets.items():html=html.replace(src,url)
 code='\n'.join((ROOT/'public'/js).read_text() for js in scripts)
 if mode=='admin':code=code.replace("const demoMode=new URLSearchParams(location.search).get('demo')==='1'","const demoMode=true").replace("location.href='/'","location.href='Storefront-Preview.html'")
 for src,url in assets.items():code=code.replace(src,url)
 html=html.replace('</body>','<script>'+mock+'\n'+code.replace('</script','<\\/script')+'</script></body>')
 (ROOT/('Storefront-Preview.html' if mode=='store' else 'Admin-Preview.html')).write_text(html)
print('Offline previews built. No credentials or live storage included.')
