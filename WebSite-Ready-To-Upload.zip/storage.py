"""Durable snapshot and auth records: SQLite locally, Firestore on Cloud Run."""
import copy, json, os, sqlite3, time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from seed import initial_catalog
CLOUD=os.getenv('STORE_BACKEND')=='firestore'
DATA=Path(os.getenv('DATA_DIR','data')); DATA.mkdir(parents=True,exist_ok=True)
if CLOUD:
 from google.cloud import firestore
 db=firestore.Client(); collection=db.collection('vytka_private')
else:
 def connect():
  c=sqlite3.connect(DATA/'shop.sqlite3',timeout=20)
  c.execute('CREATE TABLE IF NOT EXISTS records (key TEXT PRIMARY KEY, value TEXT NOT NULL)');return c

def get(key):
 if CLOUD:
  s=collection.document(key).get();return s.to_dict()['value'] if s.exists else None
 with connect() as c:
  r=c.execute('SELECT value FROM records WHERE key=?',(key,)).fetchone();return json.loads(r[0]) if r else None

def put(key,value):
 if CLOUD:
  payload={'value':value}
  if key.startswith(('session-','limit-')):payload['expiresAt']=datetime.now(timezone.utc)+timedelta(days=1)
  collection.document(key).set(payload);return
 with connect() as c:c.execute('INSERT OR REPLACE INTO records VALUES (?,?)',(key,json.dumps(value)))

def atomic(key,fn):
 if CLOUD:
  @firestore.transactional
  def run(tx):
   ref=collection.document(key);s=ref.get(transaction=tx);v=fn(s.to_dict()['value'] if s.exists else None);payload={'value':v}
   if key.startswith(('session-','limit-')):payload['expiresAt']=datetime.now(timezone.utc)+timedelta(days=1)
   tx.set(ref,payload);return v
  return run(db.transaction())
 with connect() as c:
  c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT value FROM records WHERE key=?',(key,)).fetchone();v=fn(json.loads(r[0]) if r else None);c.execute('INSERT OR REPLACE INTO records VALUES (?,?)',(key,json.dumps(v)));return v

def catalog():
 v=get('catalog')
 if v is None:v=atomic('catalog',lambda old: old or initial_catalog())
 return v

def save_catalog(value):
 expected=value.get('revision')
 saved=copy.deepcopy(value);saved['revision']=expected+1
 def change(old):
  if expected!=(old or {}).get('revision'):raise RuntimeError('conflict')
  return saved
 return atomic('catalog',change)

def throttle(key):
 now=time.time()
 def update(v):
  v=v or {'start':now,'count':0}
  if now-v['start']>900:v={'start':now,'count':0}
  v['count']+=1;return v
 return atomic('limit-'+key,update)['count']<=10
