const fs=require('node:fs');const vm=require('node:vm');const assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../public/admin.js'),'utf8');
const match=source.match(/const id=\(\)=>[^;]+;/);assert.ok(match,'ID generator must exist');
const ctx={crypto:require('node:crypto').webcrypto,Uint8Array};
// HTTP previews have getRandomValues but do not expose randomUUID.
ctx.crypto={getRandomValues:array=>require('node:crypto').webcrypto.getRandomValues(array)};
vm.createContext(ctx);vm.runInContext(match[0]+'result=id();',ctx);
assert.match(ctx.result,/^[a-zA-Z0-9_-]{1,80}$/);console.log('HTTP-preview identifier generation passed.');
