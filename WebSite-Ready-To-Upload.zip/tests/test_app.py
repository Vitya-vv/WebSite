import unittest, tempfile, os, sys, json, io, hashlib, base64
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['DATA_DIR']=tempfile.mkdtemp()
os.environ['SESSION_SECRET']='test-secret-that-is-long-and-random-enough'
salt='unit-test-salt'
os.environ['ADMIN_PASSWORD_HASH']=salt+':'+hashlib.scrypt(b'Correct-Horse-2026!',salt=salt.encode(),n=16384,r=8,p=1).hex()
os.environ['COOKIE_SECURE']='false'
try:
 from app import application
except ImportError:
 application=None

class StoreTests(unittest.TestCase):
 def call(self,path,method='GET',body=None,cookie='',csrf=''):
  self.assertIsNotNone(application,'The shop application must exist')
  data=json.dumps(body).encode() if body is not None else b''
  env={'REQUEST_METHOD':method,'PATH_INFO':path,'QUERY_STRING':'','CONTENT_LENGTH':str(len(data)),'CONTENT_TYPE':'application/json','wsgi.input':io.BytesIO(data),'HTTP_COOKIE':cookie,'HTTP_X_CSRF_TOKEN':csrf,'REMOTE_ADDR':self.id(),'HTTP_HOST':'localhost','wsgi.url_scheme':'http'}
  out={}
  def start(status,headers):out.update(status=int(status.split()[0]),headers=dict(headers))
  raw=b''.join(application(env,start));out['body']=json.loads(raw) if raw and out['headers'].get('Content-Type','').startswith('application/json') else raw
  return out
 def login(self):
  r=self.call('/api/login','POST',{'password':'Correct-Horse-2026!'})
  self.assertEqual(r['status'],200)
  return r['headers']['Set-Cookie'].split(';')[0],r['body']['csrf']
 def test_public_has_no_auth_secrets(self):
  r=self.call('/api/catalog');self.assertEqual(r['status'],200)
  self.assertNotIn('password',json.dumps(r['body']).lower());self.assertIn('products',r['body'])
 def test_anonymous_write_rejected(self):
  self.assertEqual(self.call('/api/catalog','PUT',{})['status'],401)
 def test_csrf_required(self):
  c,t=self.login();self.assertEqual(self.call('/api/catalog','PUT',{},c)['status'],403)
 def test_revision_prevents_lost_updates(self):
  c,t=self.login();s=self.call('/api/catalog')['body'];r=self.call('/api/catalog','PUT',s,c,t)
  self.assertEqual(r['status'],200);self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],409)
 def test_negative_price_rejected(self):
  c,t=self.login();s=self.call('/api/catalog')['body'];s['products'][0]['price']=-4
  self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],400)
 def test_unsafe_social_url_rejected(self):
  c,t=self.login();s=self.call('/api/catalog')['body'];s['settings']['instagram']='javascript:alert(1)'
  self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],400)
 def test_logout_revokes_cookie(self):
  c,t=self.login();self.assertEqual(self.call('/api/logout','POST',{},c,t)['status'],200)
  self.assertEqual(self.call('/api/session',cookie=c)['status'],401)
 def test_upload_requires_auth(self):
  self.assertEqual(self.call('/api/upload','POST',{})['status'],401)
 def test_login_wrong_password(self):
  self.assertEqual(self.call('/api/login','POST',{'password':'wrong'})['status'],401)
 def test_admin_is_separate_document(self):
  self.assertIn(b'admin.js',self.call('/admin')['body'])


class AdditionalSecurityTests(unittest.TestCase):
 call=StoreTests.call
 login=StoreTests.login
 def test_private_notes_not_public(self):
  c,t=self.login();s=self.call('/api/catalog',cookie=c)['body'];s['settings']['paymentNotes']='Internal integration note'
  self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],200)
  self.assertNotIn('Internal integration note',json.dumps(self.call('/api/catalog')['body']))
 def test_bad_boolean_rejected(self):
  c,t=self.login();s=self.call('/api/catalog',cookie=c)['body'];s['products'][0]['published']='false'
  self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],400)
 def test_social_sync_is_protected(self):
  self.assertEqual(self.call('/api/social-sync','POST',{})['status'],401)
 def test_public_feed_never_contains_tokens(self):
  r=self.call('/api/social-feed');self.assertEqual(r['status'],200);self.assertIsInstance(r['body'],list)

class OperationalTests(unittest.TestCase):
 call=StoreTests.call
 login=StoreTests.login
 def test_tampered_session_is_rejected(self):
  c,t=self.login();self.assertEqual(self.call('/api/session',cookie=c+'x')['status'],401)
 def test_draft_products_are_hidden(self):
  c,t=self.login();s=self.call('/api/catalog',cookie=c)['body'];p=dict(s['products'][0]);p['id']='test-private-draft';p['name']={'en':'PRIVATE DRAFT'};p['published']=False;s['products'].append(p)
  self.assertEqual(self.call('/api/catalog','PUT',s,c,t)['status'],200)
  self.assertNotIn('PRIVATE DRAFT',json.dumps(self.call('/api/catalog')['body']))
  self.assertIn('PRIVATE DRAFT',json.dumps(self.call('/api/catalog',cookie=c)['body']))
 def test_malformed_image_rejected(self):
  c,t=self.login();r=self.call('/api/upload','POST',{'data':base64.b64encode(b'not an image').decode()},c,t);self.assertEqual(r['status'],400)
 def test_real_image_uploaded_and_readable(self):
  from PIL import Image
  c,t=self.login();b=io.BytesIO();Image.new('RGB',(20,30),'red').save(b,format='PNG')
  r=self.call('/api/upload','POST',{'data':base64.b64encode(b.getvalue()).decode()},c,t);self.assertEqual(r['status'],201)
  media=self.call(r['body']['url']);self.assertEqual(media['status'],200);self.assertEqual(media['headers']['Content-Type'],'image/jpeg');im=Image.open(io.BytesIO(media['body']));self.assertEqual(im.size,(20,30))
 def test_login_attempts_limited(self):
  for _ in range(10):self.assertEqual(self.call('/api/login','POST',{'password':'bad'})['status'],401)
  self.assertEqual(self.call('/api/login','POST',{'password':'bad'})['status'],429)
 def test_scheduler_rejects_unsigned_request(self):
  self.assertEqual(self.call('/tasks/social-sync','POST',{})['status'],401)

class RetrySafetyTests(unittest.TestCase):
 def test_firestore_retry_does_not_accept_stale_catalog(self):
  import storage
  from unittest.mock import patch
  from seed import initial_catalog
  proposed=initial_catalog();proposed['revision']=7
  def simulate_retry(key,callback):
   callback({'revision':7})
   # Firestore can rerun a callback after another admin commits revision 8.
   return callback({'revision':8})
  with patch.object(storage,'atomic',simulate_retry):
   with self.assertRaises(RuntimeError):storage.save_catalog(proposed)
  self.assertEqual(proposed['revision'],7,'Caller submission must not be mutated by retries')

if __name__=='__main__':unittest.main()
