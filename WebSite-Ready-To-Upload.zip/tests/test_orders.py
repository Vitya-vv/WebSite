import unittest,os,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
class OrderTests(unittest.TestCase):
 def test_messaging_module_available(self):
  import importlib.util
  self.assertIsNotNone(importlib.util.find_spec('orders'),'Order delivery must be implemented')
 def test_order_uses_server_price_and_fixed_destination(self):
  import orders
  from seed import initial_catalog
  s=initial_catalog();v=orders.build_message(s,{'productId':'p1','size':'M','quantity':2,'name':'Alex','contact':'alex@example.test','notes':'Ivory','price':1,'recipient':'attacker'})
  self.assertIn('185',v);self.assertNotIn('attacker',v);self.assertIn('Alex',v)
 def test_invalid_quantity_rejected(self):
  import orders
  from seed import initial_catalog
  for q in [0,-1,1.5,False,99]:
   with self.assertRaises(ValueError):orders.build_message(initial_catalog(),{'productId':'p1','size':'M','quantity':q,'name':'A','contact':'a@b.test'})
 def test_invalid_or_draft_product_rejected(self):
  import orders
  from seed import initial_catalog
  s=initial_catalog();s['products'][0]['published']=False
  with self.assertRaises(ValueError):orders.build_message(s,{'productId':'p1','size':'M','quantity':1,'name':'A','contact':'a@b.test'})
 def test_tokens_expire_and_cannot_be_forged(self):
  import orders
  from unittest.mock import patch
  with patch.dict(os.environ,{'SESSION_SECRET':'x'*48}):
   with patch.object(orders.time,'time',return_value=1000):token=orders.issue_token()
   with patch.object(orders.time,'time',return_value=1003):orders.verify_token(token)
   with patch.object(orders.time,'time',return_value=3000):
    with self.assertRaises(ValueError):orders.verify_token(token)
   with self.assertRaises(ValueError):orders.verify_token(token+'bad')
 def test_delivery_is_once_and_uses_selected_owner_channel(self):
  import orders
  from unittest.mock import patch
  from seed import initial_catalog
  state=initial_catalog();state['settings'].update(automaticOrders=True,orderChannel='telegram')
  with patch.dict(os.environ,{'SESSION_SECRET':'x'*48,'TELEGRAM_BOT_TOKEN':'1234:abcd','TELEGRAM_CHAT_ID':'12345'}),patch.object(orders,'catalog',return_value=state):
   with patch.object(orders.time,'time',return_value=1000):token=orders.issue_token()
   with patch.object(orders.time,'time',return_value=1003),patch.object(orders,'provider_send') as send:
    payload={'consent':True,'channel':'telegram','token':token,'productId':'p1','size':'M','quantity':1,'name':'Alex','contact':'alex@example.test'}
    self.assertTrue(orders.deliver(payload,'test-once')['accepted']);send.assert_called_once();self.assertEqual(send.call_args.args[0],'telegram')
    with self.assertRaises(ValueError):orders.deliver(payload,'test-once')
    self.assertEqual(send.call_count,1)
 def test_unconfigured_delivery_never_sends(self):
  import orders
  from unittest.mock import patch
  with patch.dict(os.environ,{},clear=True),patch.object(orders,'provider_send') as send:
   with self.assertRaises(ValueError):orders.deliver({},'test-unconfigured')
   send.assert_not_called()
 def test_missing_reply_contact_rejected(self):
  import orders
  from seed import initial_catalog
  with self.assertRaises(ValueError):orders.build_message(initial_catalog(),{'name':'Test'})
 def test_provider_failure_is_not_reported_as_success(self):
  import orders
  from unittest.mock import patch
  from seed import initial_catalog
  state=initial_catalog();state['settings'].update(automaticOrders=True,orderChannel='telegram')
  with patch.dict(os.environ,{'SESSION_SECRET':'x'*48,'TELEGRAM_BOT_TOKEN':'1234:abcd','TELEGRAM_CHAT_ID':'12345'}),patch.object(orders,'catalog',return_value=state):
   with patch.object(orders.time,'time',return_value=4000):token=orders.issue_token()
   with patch.object(orders.time,'time',return_value=4003),patch.object(orders,'provider_send',side_effect=TimeoutError('secret URL')):
    with self.assertRaisesRegex(RuntimeError,'could not be confirmed'):orders.deliver({'consent':True,'channel':'telegram','token':token,'name':'Alex','contact':'alex@example.test'},'test-fail')
 def test_provider_payloads_have_owner_destinations(self):
  import orders
  from unittest.mock import patch
  class Response:
   def __init__(self,value):self.value=value
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self,*a):return json.dumps(self.value).encode()
  env={'TELEGRAM_BOT_TOKEN':'1234:abcd','TELEGRAM_CHAT_ID':'12345','WHATSAPP_ACCESS_TOKEN':'test-only','WHATSAPP_PHONE_ID':'123456','WHATSAPP_OWNER_NUMBER':'15551234567','WHATSAPP_TEMPLATE':'atelier_request','WHATSAPP_TEMPLATE_LANGUAGE':'en_US','VIBER_BOT_TOKEN':'test-only','VIBER_OWNER_ID':'owner-id'}
  with patch.dict(os.environ,env):
   for channel,answer in [('telegram',{'ok':True}),('whatsapp',{'messages':[{'id':'test'}]}),('viber',{'status':0})]:
    with patch.object(orders.urllib.request,'urlopen',return_value=Response(answer)) as http:
     orders.provider_send(channel,'Test inquiry')
     request=http.call_args.args[0];payload=json.loads(request.data)
     if channel=='telegram':self.assertEqual(payload['chat_id'],'12345')
     if channel=='whatsapp':self.assertEqual(payload['to'],'15551234567');self.assertEqual(payload['type'],'template')
     if channel=='viber':self.assertEqual(payload['receiver'],'owner-id')
 def test_transaction_retry_does_not_steal_existing_claim(self):
  import orders
  from unittest.mock import patch
  from seed import initial_catalog
  state=initial_catalog();state['settings'].update(automaticOrders=True,orderChannel='telegram')
  def retried(key,fn):
   fn(None)
   return fn({'claimId':'another-request','expires':99999999})
  with patch.dict(os.environ,{'SESSION_SECRET':'x'*48,'TELEGRAM_BOT_TOKEN':'1234:abcd','TELEGRAM_CHAT_ID':'12345'}),patch.object(orders,'catalog',return_value=state):
   with patch.object(orders.time,'time',return_value=6000):token=orders.issue_token()
   with patch.object(orders.time,'time',return_value=6003),patch.object(orders,'atomic',retried),patch.object(orders,'provider_send') as send:
    with self.assertRaisesRegex(ValueError,'already submitted'):orders.deliver({'consent':True,'channel':'telegram','token':token,'name':'Alex','contact':'alex@example.test'},'test-retry')
    send.assert_not_called()
