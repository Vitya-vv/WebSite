"""Optional one-time Meta connection and hourly sync. Run in Google Cloud Shell."""
import argparse,getpass,re,subprocess,json
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--region',default='us-central1');p.add_argument('--service',default='vytka-atelier');p.add_argument('--provider',choices=['instagram','facebook'],required=True);p.add_argument('--graph-version',default='v25.0');a=p.parse_args()
 for value in [a.project,a.region,a.service,a.graph_version]:
  if not re.fullmatch(r'[a-zA-Z0-9.-]+',value):p.error('Invalid option')
 root=Path(__file__).parent;base=['gcloud','--project',a.project,'--quiet']
 def cmd(args,data=None,capture=False):
  r=subprocess.run(base+args,input=data,text=True,cwd=root,capture_output=capture)
  if r.returncode:raise SystemExit('Google operation failed. Review the error and retry.')
  return r.stdout.strip() if capture else ''
 def exists(args):return subprocess.run(base+args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 account=a.service+'@'+a.project+'.iam.gserviceaccount.com';scheduler=a.service+'-sync@'+a.project+'.iam.gserviceaccount.com'
 resource=input('Authorized Instagram User ID or Facebook Page ID (digits only): ').strip()
 if not resource.isdigit():raise SystemExit('Use the numeric ID returned by Meta for the account you own.')
 token=getpass.getpass('Authorized long-lived access token (hidden): ').strip()
 if not token:raise SystemExit('Token is required.')
 secret=a.service+'-'+a.provider+'-token'
 if not exists(['secrets','describe',secret]):cmd(['secrets','create',secret,'--replication-policy=automatic'])
 version=cmd(['secrets','versions','add',secret,'--data-file=-','--format=value(name)'],token,True).rsplit('/',1)[-1]
 cmd(['secrets','add-iam-policy-binding',secret,'--member=serviceAccount:'+account,'--role=roles/secretmanager.secretAccessor','--condition=None'])
 url=cmd(['run','services','describe',a.service,'--region='+a.region,'--format=value(status.url)'],capture=True)
 cmd(['services','enable','cloudscheduler.googleapis.com'])
 if not exists(['iam','service-accounts','describe',scheduler]):cmd(['iam','service-accounts','create',a.service+'-sync','--display-name=Atelier feed scheduler'])
 envkey='IG_ACCESS_TOKEN' if a.provider=='instagram' else 'FB_PAGE_TOKEN';idkey='IG_USER_ID' if a.provider=='instagram' else 'FB_PAGE_ID'
 cmd(['run','services','update',a.service,'--region='+a.region,'--update-secrets='+envkey+'='+secret+':'+version,'--update-env-vars='+idkey+'='+resource+',META_GRAPH_VERSION='+a.graph_version+',SYNC_AUDIENCE='+url+',SCHEDULER_EMAIL='+scheduler])
 job=a.service+'-social-feed';verb='update' if exists(['scheduler','jobs','describe',job,'--location='+a.region]) else 'create'
 cmd(['scheduler','jobs',verb,'http',job,'--location='+a.region,'--schedule=17 * * * *','--time-zone=Etc/UTC','--uri='+url+'/tasks/social-sync','--http-method=POST','--oidc-service-account-email='+scheduler,'--oidc-token-audience='+url,'--message-body={}'])
 cmd(['scheduler','jobs','run',job,'--location='+a.region])
 print('Connection configured; hourly sync requested. Review Social & journal in /admin for connection health. Meta permissions may require review or reconnection.')
if __name__=='__main__':main()
