# Order messages: WhatsApp, Viber and Telegram

## Owner controls

In **/admin → Social & journal**:

1. Choose **Receive inquiries via**: WhatsApp, Viber, Telegram, Instagram, Facebook or email.
2. Add the public contact number/profile for the selected service. Phone numbers use `+` and country code, e.g. `+380...`. Telegram links use `https://t.me/yourusername` without query parameters.
3. For direct sending, complete the one-time server connection below and enable **Send directly from the website**. Save.
4. Test from the storefront using your own details. The customer must enter a name and reply contact and agree to share them. No account is required.

**Two modes:**

- **Chat mode:** customer opens the chosen app. WhatsApp supports a prepared draft; Telegram may support a draft for the named account. Viber launches the app; copy/paste is the reliable fallback. The customer presses Send in the messaging app. Browser/app restrictions can affect links.
- **Direct mode:** customer presses **Send request on the website**. The server sends a notification to the owner's fixed, connected destination. It comes from the bot/business account, not from the customer's personal messaging account. The owner replies using the contact entered by the customer. Instagram/Facebook/email remain chat-link modes in this version.

No live account is connected in the deliverable. No messages were sent during development. The automatic mode remains off by default. If credentials are missing, the site offers the chat fallback. Credentials present are not proof of provider permissions; test before opening to customers.

## Easiest direct connection: Telegram

1. In Telegram open the official **@BotFather** account and create your own bot with `/newbot`.
2. Keep its token private. Open the new bot from the owner's Telegram account and send `/start`.
3. In authenticated Google Cloud Shell, from the deployed source folder, run:

```bash
python3 connect-messaging.py --project YOUR_PROJECT_ID --provider telegram
```

4. Enter the token at the hidden prompt. Enter your chat ID or let the helper look up the private chat IDs after `/start`. Select only the owner's chat. If a webhook already handles this bot, getUpdates may not work: supply the known authorized owner chat ID instead. Do not remove a webhook used by another system.
5. In the admin area select Telegram, add the owner's public reply/profile link, enable direct sending, save and submit one test inquiry.

## WhatsApp direct connection

A normal WhatsApp phone number or wa.me link **does not** allow the website to send automatically. Direct delivery requires an authorized **WhatsApp Business Platform / Cloud API** sender. Obtain the business sender phone-number ID, access token, owner recipient phone and recipient opt-in. The owner recipient must be able to receive from that business sender; don't assume the sender can message itself.

Because notifications can be outside a customer-service window, this implementation uses an approved template. Create and obtain Meta approval for a template with **one body text parameter `{{1}}`** and no required header/button parameters. Example concept: “New website inquiry: {{1}}”. Approval/category eligibility is Meta's decision. The parameter contains a compact single-line summary, up to 1000 characters. Keep customer wishes short. Meta or your provider may charge for sending.

Run:

```bash
python3 connect-messaging.py --project YOUR_PROJECT_ID --provider whatsapp
```

Enter the authorized token, sender phone-number ID, opted-in recipient number (country code and digits only), approved template name and exact language code. Then select WhatsApp and enable direct delivery in admin. A connection test with the real authorized service is required. A successful API response only means acceptance for processing; a delivery receipt/read receipt is not implemented.

## Viber direct connection

Use an authorized active Viber bot. New bots are subject to Viber's commercial terms. The owner must subscribe/start the bot; a normal phone number alone is not a bot receiver ID. Obtain the subscribed owner's receiver ID through your authorized bot integration/webhook. This package does not build or configure a Viber subscription webhook for you.

```bash
python3 connect-messaging.py --project YOUR_PROJECT_ID --provider viber
```

Enter the bot token and subscribed owner receiver ID. In admin, select Viber, add the public contact number for fallback, enable direct mode and save. Test using the real bot. Commercial onboarding/fees remain outside this software.

## Secrets and local testing

The helper stores tokens in Secret Manager and gives the deployed runtime access to the specific secret. It updates existing environment settings without removing the feed connection. Never put tokens in source files, GitHub, catalog exports, payment notes, customer fields or public URLs.

For local development, set the same environment variables before running run.py; do not commit their values. Supported private variables:

- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`
- `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_ID`, `WHATSAPP_OWNER_NUMBER`, `WHATSAPP_TEMPLATE`, `WHATSAPP_TEMPLATE_LANGUAGE`
- `VIBER_BOT_TOKEN`, `VIBER_OWNER_ID`

The WhatsApp Graph API version uses `META_GRAPH_VERSION` (default `v25.0`). Match the version supported by your application.

## Delivery and abuse handling

Messages include customer name/contact, canonical product name/ID, validated size and quantity, current server price and wishes. A visitor cannot choose another receiver or override server price. General inquiries are also supported.

Expiring signed form tokens, a honeypot field, per-address limits (5 attempts/15 minutes), a global limit (50 attempts/15 minutes), and one-use submission reservations reduce abuse. Limits apply to server-observed addresses; proxies can group visitors. These measures are not a full bot-defense service: monitor abuse/costs and add an edge bot/rate-limit service for public launches as needed.

Only one delivery attempt is made per token. If a provider times out after accepting a message, the website cannot prove whether it arrived; it shows “could not confirm” and does not automatically retry. Reopening a form can create another inquiry, so don't resend blindly. There is no background queue, guaranteed delivery, inventory reservation, payment or automatic order acceptance.

The website does not store message text/contact in its database. It stores short-lived submission/rate records; Google Firestore TTL on `expiresAt` cleans these with the other temporary records. The chosen messaging provider and owner receive and may retain the submitted personal details. Update your shop's privacy/retention policy accordingly. Customers explicitly consent before submitting.

References: https://core.telegram.org/bots/api#sendmessage ; https://faq.whatsapp.com/5913398998672934 ; https://developers.viber.com/rest/ ; https://help.viber.com/hc/en-us/articles/15247629658525-Bot-commercial-model
