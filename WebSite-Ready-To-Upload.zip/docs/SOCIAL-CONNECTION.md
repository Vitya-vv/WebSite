# Optional automatic Instagram / Facebook posts

The shop works with ordinary social contact links and manually added post cards immediately. An automatic recent-post feed is optional. The implementation is included but **no account is connected in this deliverable**. Never paste an access token into chat, a product description, an image URL or payment notes.

## What needs authorization

The owner must have the rights to the account/Page and authorize an appropriate Meta developer application. Instagram's professional-account API requires a supported Business/Creator account. Instagram Login uses the `instagram_business_basic` permission to read the owner's media. Facebook Page posts use the appropriate Page access token and permissions such as `pages_read_engagement`; the developer flow may also require `pages_show_list` when selecting a Page. Meta may require App Review/business verification depending on app mode, permission access and who uses the app. A professional developer should complete that initial authorization using Meta's current documentation.

No end-customer social sign-in is needed. The website does not publish or send messages on behalf of customers. Their order is still copied into their own chat and sent by them.

## Connect after deploying Google hosting

1. In your Meta app, authorize only the account/Page the owner controls. Obtain the numeric Instagram User ID or Facebook Page ID and a valid **long-lived** access token with the needed read permissions.
2. In your own authenticated Google Cloud Shell, from the extracted project folder, run:

```bash
python3 connect-meta.py --project YOUR_REAL_PROJECT_ID --provider instagram
# Or, for a Facebook Page:
python3 connect-meta.py --project YOUR_REAL_PROJECT_ID --provider facebook
```

Use `--region` and `--service` if you changed these in deployment. `--graph-version` defaults to `v25.0`; confirm a supported version for your Meta application before connecting.

3. The script prompts for the numeric ID and securely requests the token through a hidden terminal prompt. It stores the token in a dedicated Secret Manager secret, grants read permission to the runtime service account, injects it into Cloud Run, and configures an hourly Cloud Scheduler job. It prints no token. Do not type tokens as command-line arguments.
4. In `/admin`, open **Social & journal**. The automatic-feed panel shows whether server credentials exist, the last attempted sync, card count where available, and a connection error if the provider rejected access. Credential presence alone is not proof of a working connection. Click **Sync recent posts** to test; then check the storefront.
5. Publish a new real post on the account and verify the hourly job imports it. Check Google Cloud Scheduler execution logs if it does not. This live verification must be done with the real authorized account.

## How it works

The server requests up to six recent Instagram items and six Facebook posts with photographs. Instagram videos use thumbnails. Text-only Facebook posts are not displayed as photo cards. No post is sent or edited. Captions retain their original language; the surrounding shop controls still follow the customer's language choice.

A cached feed is stored privately in Firestore. The public `/api/social-feed` endpoint returns only post captions, image URLs and post links. It never returns tokens or provider error bodies. If one provider fails, its previous cards are retained; the admin receives a generic action message. Remote image URLs can expire, so an interrupted connection can eventually leave stale images until reconnected.

Hourly job calls are verified using a Google-issued OIDC ID token (a signed identity proof). The audience must equal the Cloud Run service URL, and the token's verified email must match the designated Scheduler account. Arbitrary anonymous calls to `/tasks/social-sync` are rejected. Administrator-triggered sync uses the normal session/CSRF protection.

Instagram long-lived tokens are refreshed after 25 days of use by this job. The refreshed token is stored in a private Firestore record; reconnecting with a new initial token resets it. This is not a guarantee of permanent access: revoked permissions, expired initial tokens, password changes, Meta policy changes, API version retirement or extended job failures may require authorization again. Facebook Page tokens have their own validity rules and can be revoked; the script does not fabricate automatic renewal for them.

## Troubleshooting

- **Not configured:** run the connection helper in the same project/region/service as deployment.
- **Configured but no posts:** check permissions, numeric account ID, supported API version, app access mode, and whether posts contain supported media.
- **Permission/token error:** authorize again using Meta's supported flow, then rerun `connect-meta.py` with the replacement token. Do not share it.
- **Scheduled job fails:** confirm Scheduler service-account identity and Cloud Run's `SYNC_AUDIENCE` and `SCHEDULER_EMAIL`. The initial operator must have permission to use that service account; Google's Scheduler service agent needs its normal token-creation permissions.
- **Contact buttons fail:** these are separate from the automatic feed. Set normal profile/Page links in Social & journal and test the chat on a phone.
- **No Meta application desired:** use manual post cards. They need only a post link, a cover image the owner may use, and a caption.

References: [Instagram overview](https://developers.facebook.com/documentation/instagram-platform/overview), [Business Login](https://developers.facebook.com/documentation/instagram-platform/instagram-api-with-instagram-login/business-login), [Token refresh](https://developers.facebook.com/documentation/instagram-platform/reference/refresh_access_token).
