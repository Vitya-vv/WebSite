# VYTKA / Server — handmade clothing boutique

A working, portable shop with a separate administrator area. VYTKA is a temporary, editable brand name. English, Ukrainian, Russian and Polish are included in the storefront and administration.

## Start here

1. Extract the ZIP. Open `START-HERE.html` for an overview and offline previews.
2. To run the real application on Windows, install Python 3.11 or newer and double-click `start-windows.bat`. It installs dependencies in an isolated `.venv` folder and asks you to choose an administrator password. Do not share that password.
3. Open `http://localhost:8080/` for the shop; open `http://localhost:8080/admin` to sign in. First sign-in opens the setup walkthrough.
4. For Linux/macOS: `python3 -m venv .venv`, activate it, run `python -m pip install -r requirements.txt`, then `python setup.py` and `python run.py`.

The offline preview uses sample data only. Its admin changes stay in the current tab and disappear after reload. It does not upload photos, sign in, or modify a running server. The real app uses protected server APIs and durable storage.

## What the owner can manage

- Products: add, edit, duplicate, publish/unpublish, delete, and feature.
- Four-language names, descriptions, materials, care and production times.
- Custom order or limited stock; sizes; stock count; image galleries.
- Price in the chosen currency or a blank price for a discreet pricing inquiry. **0 means free**, not hidden.
- Collections become storefront tabs; arrow buttons reorder them. Move products out of a collection before deleting it.
- Additional informational pages: add translations, edit, publish or delete. Published pages appear in the navigation and as sections below the journal.
- Brand name, introduction, homepage image, story, shipping text, default language, accent color and optional Ukrainian ornaments.
- Instagram/Facebook contact links and optional email.
- Manual social post cards; an optional authorized automatic feed.
- Searchable, translated help and a six-step setup walkthrough.
- Catalog export and restore; administrator sign-out.

Brand text and built-in interface labels are different: the owner edits content in the admin panel; fixed interface translations are in `public/i18n.js` and `public/admin-i18n.js`. Empty content translations fall back to English, then another available language. No machine translation is performed. Imported social captions retain their original language.

## Direct messaging update

WhatsApp, Viber and Telegram are now selectable in **Social & journal**. The owner selects one request destination. Optional direct delivery sends from the website through an authorized Telegram bot, WhatsApp Business approved template or Viber bot. It is off until connected. Customers provide a name/reply contact and explicitly press Send. See [messaging setup](docs/MESSAGING.md) for one-time connection, costs and limitations. Original chat links remain as fallback.

## Customer ordering

A customer opens an item, chooses size and quantity, and optionally enters measurements, colors or delivery wishes. The site creates an editable message with the product ID, link and advertised price/quantity where present. The customer copies it and opens the configured chat. Instagram uses `ig.me/m/username`; Facebook uses `m.me/PageID` with a text parameter, plus the copy-and-paste fallback.

In chat-link mode, the customer must send the message. In connected direct mode, the customer submits the website form and the server forwards it to the selected owner channel. Browsers and social apps can restrict prefilling. The owner confirms availability, sizing, price, delivery and payment in the conversation. An inquiry does not reserve stock or create a paid order. Update remaining stock manually after agreeing a sale.

Only normal Instagram username profile URLs and Facebook Page URLs or numeric Page IDs are intended for these contact settings. Test both from a real mobile device. Messenger must be enabled for the Page. For Facebook profile URLs with `profile.php?id=...`, the numeric ID is used.

## Payment readiness

No card fields, checkout, payment processing, or provider credentials are present. The admin can save a preferred future provider (PayPal or Stripe, which can process supported cards such as Visa). This is a planning setting only. Enabling real payments requires developer work: provider-hosted checkout, server-verified pricing, payment notification verification, inventory/order records, refunds, and relevant policies. Never enter secrets or card data in product descriptions or notes.

## Google Cloud deployment

This environment has **not deployed the shop to Google** and contains no Google account credentials. The deployment helper is supplied for an authenticated project owner to run. No hosted production URL is claimed.

Recommended: use a dedicated Google Cloud project with billing enabled. Open [Google Cloud Shell](https://shell.cloud.google.com/) in your own account, upload/extract this folder, and work in its root. `gcloud` must be signed in to the intended account. The provisioning script requires permission to enable services, create service accounts/resources, grant IAM roles, create secrets, deploy Cloud Run and allow public visitors; Project Owner is the simplest one-time operator role. Organization policies may require your organization's administrator.

Run:

```bash
python3 setup.py
python3 deploy-google.py --project YOUR_REAL_PROJECT_ID --region us-central1
```

The first command securely prompts for your administrator password and creates `local-config.json` with a password hash and random session secret. The deployment helper passes those values to Google Secret Manager via stdin, not command-line arguments. `local-config.json` is excluded from Google uploads, Docker builds and version control. Keep it private and retain a secure copy for redeployments; its hash and session secret are sensitive.

The helper creates/configures:

- Cloud Run service `vytka-atelier`, deployed from the supplied Dockerfile. Public visitors can read the storefront; admin mutations still require application authentication.
- A dedicated runtime service account with Firestore User access and bucket-scoped Storage Object User access.
- A Firestore **Native mode** default database. Do not use a Datastore mode database.
- A private Cloud Storage bucket with uniform access, public access prevention and object versioning. Images are served by the application from this private bucket; no public bucket is needed.
- Two secret-specific Secret Manager permissions. The runtime receives pinned versions of administrator and session secrets.
- Cloud Build/Artifact Registry source-build prerequisites and the documented Cloud Run Builder role on the default build service identity, separate from the runtime identity.
- Scale-to-zero with maximum 3 instances, 512 MiB memory and request concurrency 16 per instance. Adjust only after measuring real traffic. A cold start may delay the first visit.

If IAM changes have not propagated, wait a few minutes and rerun the helper. It retains existing resources. If your organization does not allow public Cloud Run services, ask its administrator for the supported public routing approach.

**After first deployment:**

1. Visit the printed HTTPS address and `/admin`. Run the owner walkthrough.
2. Replace every sample design/illustration with the owner's actual photographs and descriptions. Replace the generated sample hero image. Review all four translations.
3. Add real contact links, verify messages on a phone, set shipping/returns/business details, and publish the real products. Turn off the sample-content notice only after replacing sample content.
4. Set a Google billing budget and alerts. Budgets are notifications, not a hard spending cap. Cloud Run, storage, database reads, image transfer, builds, backups and optional Scheduler can incur charges.
5. In Firestore, enable a scheduled backup policy and consider point-in-time recovery (PITR: restoring data to an earlier time). Configure retention suitable for the business. This is a required owner/operator step, not something this package silently claims to have enabled.
6. Enable the expiration policy for temporary login records:

```bash
gcloud firestore fields ttls update expiresAt --collection-group=vytka_private --enable-ttl --project YOUR_REAL_PROJECT_ID
```

TTL means time to live: Google removes expired session/throttle records asynchronously. Session checks themselves enforce expiry immediately, so delayed TTL cleanup cannot extend access. The catalog, feed and privately retained refreshed token have no TTL expiration.

7. Configure a custom domain through a Google-supported Cloud Run domain mapping or HTTPS load balancer, including your DNS (domain routing records). Availability depends on the region and domain setup. The printed Google HTTPS URL works first; no domain is purchased or configured by this package.

### Honest maintenance expectations

Managed Google services remove operating-system/server administration. Ordinary catalog changes require no coding or redeployment. The included Docker image and Python packages still need periodic rebuilds/redeployment for security patches; review them at least quarterly and when a relevant security issue appears. The supplied Dockerfile does not automatically patch already running containers. Meta permissions or token revocation can require reconnection. Keep backups, billing alerts and a recovery contact current. This is low-maintenance, not a promise of zero maintenance.

## Storage, structure and limits

| File/service | Purpose |
|---|---|
| `app.py` | WSGI (Python web-server interface), routing, login, validation, image handling and security headers |
| `storage.py` | Local SQLite or production Firestore; atomic, retry-safe revision checks |
| `seed.py` | Four-language sample data |
| `social.py` | Optional authorized Meta feed and Scheduler identity verification |
| `public/index.html`, `style.css`, `store.js` | Responsive customer storefront |
| `public/admin.html`, `admin.css`, `admin.js` | Separate admin UI and isolated preview mode |
| `public/i18n.js`, `admin-i18n.js` | Four-language fixed interface text |
| `public/assets/` | Included sample illustration assets and AI-generated editorial image |
| `local-config.json` | Private local credentials generated by the owner; never in the deliverable ZIP |
| `data/shop.sqlite3`, `data/uploads/` | Local-only database and uploads created while running |
| Firestore collection `vytka_private` | Production catalog, session/throttle records and optional private feed/token state |
| Private Cloud Storage bucket | Uploaded and optimized production photographs |
| `setup.py`, `run.py`, `start-windows.bat` | Local installation and start |
| `deploy-google.py`, `Dockerfile`, `requirements.txt` | Google deployment and runtime dependencies |
| `connect-meta.py` | Optional authorized feed connection and hourly Scheduler job |

Catalog text is stored as one revision-controlled snapshot, intentionally simple for a small atelier. Limits: 500 products, 40 collections, 30 pages, 12 manual post cards, 12 photos per product, 750 KB of catalog JSON text. Image bytes are outside the catalog. Maximum image upload: 6 MB and 24 million pixels; images become metadata-free JPEGs up to 2200 × 2200 pixels. Keep product photography separate from personal files. Concurrency conflicts return a clear error; reload before editing again rather than overwriting another admin's change.

Deleting a product does not automatically delete uploaded files, so historical backups can still reference them. Review unused media and storage retention periodically. This package intentionally does not offer a destructive bulk media cleanup button.

## Backup and recovery

The admin's JSON export contains the catalog, translated content, settings, private integration notes and image **references**. It excludes actual photos, passwords, sessions, access tokens and automatic feed records. Export before major changes. Store backups privately.

- **Local full backup:** stop the local server, copy `data/` and keep a private copy of `local-config.json` separately. Restore while the server is stopped.
- **Google full backup:** retain Firestore scheduled backups/PITR and Cloud Storage backups/versioning. Catalog JSON alone cannot recover missing photographs. A restored catalog that references another deployment's `/media/` paths needs matching image objects copied to the new bucket.
- **Restore catalog:** sign in → Backup & security → choose JSON export → confirm replacement. The server validates it and checks the current revision.
- **Lost admin password:** run `setup.py` again, choose a new password, then rerun deployment using the new configuration. This replaces both administrator credentials and the session secret, invalidating active sessions. For an existing Google deployment, preserve project/service/region arguments.
- **Rebuild or update:** keep the local credential configuration and run `deploy-google.py` again. Firestore and Storage data remain separate from container revisions. The deployment helper updates its own environment/secret keys and preserves an existing optional Meta connection.

## Security design

No customer accounts; one administrator login. Direct inquiries require customer consent and are subject to rate limits. Passwords use scrypt (a deliberately expensive password hashing method) with a random salt. Production secrets live in Secret Manager. Eight-hour sessions use random IDs and signed, HttpOnly, Secure, SameSite=Strict cookies. CSRF (cross-site request forgery: making a browser perform an unwanted authenticated action) checks protect writes. Cookies are intentionally non-Secure only for the local HTTP runner.

Login attempts are persistently limited to 10 per 15-minute window per server-observed remote address. Behind a proxy that groups remote addresses, the effective limit may be shared; test with your deployment and use a Google edge rate-limit policy if stronger network-level controls are needed. The app does not trust arbitrary client-supplied forwarding headers. Expired sessions cannot be reused; logout revokes the server record. Password-hash changes invalidate existing sessions.

Catalog inputs and outbound social/image links are validated; displayed content is escaped. Uploaded photographs are decoded and re-encoded; SVG uploads are not accepted. Private integration notes and unpublished products/pages are excluded from public catalog responses. Provider secrets never appear in the catalog or exports. Browsers receive restrictive content-security, framing and MIME-sniffing headers. `/admin?demo=1` is a client-only sample-data mode; it grants no admin session and cannot write through protected APIs.

This is not a formal penetration test or a certification of security/compliance. Configure business/legal policies for the jurisdictions where the owner sells, and review the deployment before accepting real orders.

## Verification performed

- Python integration suite: login failure/success, unauthorized writes/uploads, CSRF, logout revocation, invalid prices/URLs/booleans, private notes exclusion, revision conflicts, feed protection and public response shape.
- JavaScript syntax checks and regression test for admin IDs on ordinary HTTP preview origins.
- Browser review: customer storefront; Ukrainian/Polish switching; product detail; prepared pricing message; admin walkthrough in isolated demo mode; adding a sample product in that preview.
- Live Google provisioning, actual Secret Manager/Firestore/Storage access, real Meta feeds, real social-app behavior and real payments **were not exercised** because no owner service accounts were connected. Mobile layout uses responsive CSS but has not had a device/browser matrix test.

Run checks:

```bash
python -m unittest discover -s tests -v
node tests/test_frontend.cjs
node --check public/store.js
node --check public/admin.js
python -m compileall -q app.py storage.py seed.py social.py
```

## References

- [Google: Deploy Cloud Run services from source](https://docs.cloud.google.com/run/docs/deploying-source-code)
- [Google: Connect to Google Cloud services](https://docs.cloud.google.com/run/docs/integrate/using-gcp-services)
- [Meta: Instagram platform overview](https://developers.facebook.com/documentation/instagram-platform/overview)
- [Meta: Instagram business login](https://developers.facebook.com/documentation/instagram-platform/instagram-api-with-instagram-login/business-login)
- [Meta: Refresh access token](https://developers.facebook.com/documentation/instagram-platform/reference/refresh_access_token)

Image disclosure: `public/assets/atelier-editorial.jpg` is generated sample concept imagery, not a photograph of an item actually sold. Built-in image generation was used with the prompt: “Editorial portrait crop of an adult woman in an ivory linen vyshyvanka with delicate muted burgundy Ukrainian geometric embroidery, warm stone plaster backdrop, soft afternoon light, tactile natural fabric, no text/logos.” The SVG clothing studies are illustrative samples. Replace these before launch. Fonts are local/system fonts; no third-party tracking, social scripts, analytics, or CDN libraries are loaded.
