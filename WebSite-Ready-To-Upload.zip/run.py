"""Local preview only. Production uses gunicorn and Secret Manager."""
import argparse,json,os,runpy
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--host');parser.add_argument('--port');parser.add_argument('--strictPort',action='store_true');args=parser.parse_args()
if args.port:os.environ['PORT']=args.port
root=Path(__file__).parent
p=root/'local-config.json'
if p.exists():
 for k,v in json.loads(p.read_text()).items():os.environ.setdefault(k,v)
os.environ.setdefault('COOKIE_SECURE','false');os.environ.setdefault('DATA_DIR',str(root/'data'))
runpy.run_path(str(root/'app.py'),run_name='__main__')
