"""Opt-in Meta feed. Access tokens never leave the server or catalog export."""
import hashlib,json,os,re,time,urllib.parse,urllib.request
from storage import get,put,atomic

def configured():return bool(os.getenv('IG_ACCESS_TOKEN') and re.fullmatch(r'\d+',os.getenv('IG_USER_ID','')) or os.getenv('FB_PAGE_TOKEN') and re.fullmatch(r'\d+',os.getenv('FB_PAGE_ID','')))
def status():
 s=get('social-feed') or {}
 return {'configured':configured(),'instagram':bool(os.getenv('IG_ACCESS_TOKEN') and os.getenv('IG_USER_ID')),'facebook':bool(os.getenv('FB_PAGE_TOKEN') and os.getenv('FB_PAGE_ID')),'lastSync':s.get('lastSync'),'error':s.get('error'),'count':len(s.get('posts',[]))}
def public_feed():return (get('social-feed') or {}).get('posts',[])

def request(host,path,token,params):
 # Host is fixed in code. Authorization is never sent to a user-controlled URL.
 url='https://'+host+'/'+path.lstrip('/')+'?'+urllib.parse.urlencode(params)
 req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,'Accept':'application/json'})
 with urllib.request.urlopen(req,timeout=15) as response:return json.loads(response.read(2_000_000))

def https_url(v,hosts=None):
 if not isinstance(v,str):return False
 u=urllib.parse.urlparse(v)
 return u.scheme=='https' and bool(u.hostname) and not u.username and (hosts is None or u.hostname in hosts)

def sync():
 if not configured():return {'ok':False,'error':'Meta credentials are not configured. Follow docs/SOCIAL-CONNECTION.md.'}
 now=time.time();locked=False
 def lock(old):
  nonlocal locked
  if old and old['until']>now:return old
  locked=True;return {'until':now+90}
 atomic('social-lock',lock)
 if not locked:return {'ok':False,'error':'A sync is already running. Try again shortly.'}
 old=get('social-feed') or {};posts=[];errors=[];version=os.getenv('META_GRAPH_VERSION','v25.0')
 if not re.fullmatch(r'v\d+\.0',version):return {'ok':False,'error':'Invalid Meta API version'}
 ig_token=os.getenv('IG_ACCESS_TOKEN');ig_id=os.getenv('IG_USER_ID')
 if ig_token and ig_id and re.fullmatch(r'\d+',ig_id):
  try:
   # Refreshed long-lived token is retained privately; credential rotation resets it.
   fingerprint=hashlib.sha256(ig_token.encode()).hexdigest();saved=get('instagram-token') or {}
   if saved.get('fingerprint')!=fingerprint:saved={'token':ig_token,'fingerprint':fingerprint,'refreshed':now};put('instagram-token',saved)
   if now-saved['refreshed']>25*86400:
    refreshed=request('graph.instagram.com','refresh_access_token',saved['token'],{'grant_type':'ig_refresh_token'})
    saved.update(token=refreshed['access_token'],refreshed=now);put('instagram-token',saved)
   data=request('graph.instagram.com',version+'/'+ig_id+'/media',saved['token'],{'fields':'id,caption,media_url,permalink,media_type,thumbnail_url,timestamp','limit':6})
   for item in data.get('data',[]):
    url=item.get('permalink','');photo=item.get('thumbnail_url') if item.get('media_type')=='VIDEO' else item.get('media_url')
    if https_url(url,{'www.instagram.com','instagram.com'}) and https_url(photo):
     caption=str(item.get('caption',''))[:1200];posts.append({'id':'ig-'+str(item['id']),'url':url,'image':photo,'caption':{l:caption for l in ['en','uk','ru','pl']},'source':'instagram','timestamp':item.get('timestamp','')})
  except Exception:errors.append('Instagram connection needs attention. Check permissions, account ID and token validity.')
 fb_token=os.getenv('FB_PAGE_TOKEN');fb_id=os.getenv('FB_PAGE_ID')
 if fb_token and fb_id and re.fullmatch(r'\d+',fb_id):
  try:
   data=request('graph.facebook.com',version+'/'+fb_id+'/posts',fb_token,{'fields':'id,message,full_picture,permalink_url,created_time','limit':6})
   for item in data.get('data',[]):
    url=item.get('permalink_url','');photo=item.get('full_picture','')
    if https_url(url,{'www.facebook.com','facebook.com'}) and https_url(photo):
     caption=str(item.get('message',''))[:1200];posts.append({'id':'fb-'+str(item['id']),'url':url,'image':photo,'caption':{l:caption for l in ['en','uk','ru','pl']},'source':'facebook','timestamp':item.get('created_time','')})
  except Exception:errors.append('Facebook connection needs attention. Check Page permissions and token validity.')
 # Preserve the last working cards for a failed provider. Never show error details publicly.
 failed={'instagram' for e in errors if e.startswith('Instagram')}|{'facebook' for e in errors if e.startswith('Facebook')}
 posts.extend(p for p in old.get('posts',[]) if p.get('source') in failed)
 posts.sort(key=lambda p:p.get('timestamp',''),reverse=True)
 error=' '.join(errors)
 put('social-feed',{'posts':posts[:12],'lastSync':now,'error':error});put('social-lock',{'until':0})
 return {'ok':not errors,'count':len(posts),'error':error,'lastSync':now}

def verify_scheduler(env):
 audience=os.getenv('SYNC_AUDIENCE');email=os.getenv('SCHEDULER_EMAIL');auth=env.get('HTTP_AUTHORIZATION','')
 if not audience or not email or not auth.startswith('Bearer '):return False
 try:
  from google.oauth2 import id_token
  from google.auth.transport import requests
  claims=id_token.verify_oauth2_token(auth[7:],requests.Request(),audience)
  return claims.get('email')==email and claims.get('email_verified') is True
 except Exception:return False
